const toggleMenu = () => {
  const menu = document.getElementById("fullscreenMenu");
  if (menu) menu.classList.toggle("show");
};
